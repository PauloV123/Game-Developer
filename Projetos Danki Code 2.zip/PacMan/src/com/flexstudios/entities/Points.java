package com.flexstudios.entities;

import java.awt.image.BufferedImage;

public class Points extends Entity{

	public Points(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
	}

}
