package com.flexstudios.entities;



import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;

public class Player extends Entity {
	
	public boolean right, up, left, down;
	public BufferedImage[] sprite_left;
	public BufferedImage[] sprite_right;
	public BufferedImage[] sprite_up;
	public BufferedImage[] sprite_down;
	public static int CUR_LEVEL = 1, MAX_LEVEL = 2;
	public static boolean GhostOn = false;
	public static boolean GhostOff = true;;
	private int frames = 0, maxFrames = 8, index = 0, maxIndex = 2;
	public int lastDir = 1;
	public boolean moved = false;
	public boolean isDamaged = false;
	private int damageFrame = 0;
	public BufferedImage[] sprite_die;
	
	
	public Player(int x, int y, int width, int height,double speed ,BufferedImage sprite) {
		super(x, y, width, height,speed, sprite);
		sprite_right = new BufferedImage[3];
		sprite_left = new BufferedImage[3];
		sprite_up = new BufferedImage[3];
		sprite_down = new BufferedImage[3];
		sprite_die = new BufferedImage[4];
		
		for(int i = 0; i < 3; i++) {
			sprite_right[i] = Game.spritesheet.getSprite(32+(i*16), 0, 16, 16);
		}
		for(int i = 0; i < 3; i++) {
			sprite_left[i] = Game.spritesheet.getSprite(32+(i*16), 16, 16, 16);
		}
		for(int i = 0; i < 3; i++) {
			sprite_up[i] = Game.spritesheet.getSprite(32, 32+(i*16), 16, 16);
		}
		for(int i = 0; i < 3; i++) {
			sprite_down[i] = Game.spritesheet.getSprite(48, 32+(i*16), 16, 16);
		}
		for(int i = 0; i < 4; i++) {
			sprite_die[i] = Game.spritesheet.getSprite(32, 80+(i*16), 16, 16);
		}
				
	}
	
	public void tick() {
		depth = 1;
		if(isDamaged == false) {	
			if(right && World.isFree((int)(x+speed),this.getY())) {
				x+=speed;
				lastDir = 1;
				moved = true;
			}else if(left && World.isFree((int)(x-speed),this.getY())) {
				x-=speed;
				lastDir = -1;
				moved = true;
			}
			if(up && World.isFree(this.getX(),(int)(y-speed))) {
				y-=speed;
				lastDir = 2;
				moved = true;
			}else if(down && World.isFree(this.getX(),(int)(y+speed))) {
				y+=speed;
				lastDir = -2;
				moved = true;
			}	
		}
		if(x >= Game.WIDTH) {
			x = -16;
		}else if(x+16 < 0) {
			x = Game.WIDTH;
		}
		
		
		CollisionWithPoint();
		CollisionWithPower();
		if(moved) {
			frames++;
			if(frames == maxFrames) {
				frames = 0;
				index++;
				if(index > maxIndex) {
					index = 0;
				}
			}
			
		}
		
		if(isDamaged) {
			this.damageFrame++;
			if(this.damageFrame == 8) {
				this.damageFrame = 0;
				isDamaged = true;
			}
		}
		
		
		
		if(Game.points_atual == Game.points_contagem) {
			CUR_LEVEL++;
			String newWorld = "level"+CUR_LEVEL+".png";
			World.restartGame(newWorld);
		}
	
	}
	
	public void CollisionWithPoint() {
		for(int i = 0; i < Game.entities.size();i++) {
			Entity current = Game.entities.get(i);
			if(current instanceof Points) {
				if(Entity.isColidding(this, current)) {
					Game.points_atual++;
					Game.points_game+=100;
					
					Game.entities.remove(i);
					return;
					
				}
			}
		}
	}
	public void CollisionWithPower() {
		for(int i = 0; i < Game.entities.size();i++) {
			Entity current = Game.entities.get(i);
			if(current instanceof Power) {
				if(Entity.isColidding(this, current)) {
					Enemy.ghostMode = true;
					Game.entities.remove(i);
					return;	
				}
			}
		}
	}
	
	public void render(Graphics g) {
		if(isDamaged == false) {
			if(lastDir == 1) {
				g.drawImage(sprite_right[index],this.getX()- Camera.x, this.getY() - Camera.y, null);
			}else if(lastDir == -1){
				g.drawImage(sprite_left[index],this.getX()- Camera.x, this.getY() - Camera.y, null);
			}else if(lastDir == 2) {
				g.drawImage(sprite_up[index],this.getX()- Camera.x, this.getY() - Camera.y, null);
			}else if(lastDir == -2) {
				g.drawImage(sprite_down[index],this.getX()- Camera.x, this.getY() - Camera.y, null);
			}
		} 
		if(isDamaged == true) {
			g.drawImage(sprite_die[index],this.getX()- Camera.x, this.getY() - Camera.y, null);
		}
	}
	public static void main(String[] args) {
		

	}

}
