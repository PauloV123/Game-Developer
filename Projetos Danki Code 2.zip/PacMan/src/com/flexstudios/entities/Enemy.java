package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;
import com.flexstudios.main.Game;
import com.flexstudios.main.Sound.Clips;
import com.flexstudios.world.AStar;
import com.flexstudios.world.Camera;
import com.flexstudios.world.Vector2i;
import com.flexstudios.world.World;



public class Enemy extends Entity{
	
	public static boolean ghostMode = false;
	public int ghostFrames = 0;
	private int frames = 0, maxFrames = 10, index = 0, maxIndex = 2;
	private BufferedImage[] ghostEnemy;
	public Enemy(int x, int y, int width, int height,double speed, BufferedImage sprite) {
		super(x, y, width, height, speed,sprite);
		ghostEnemy = new BufferedImage[3];
		for(int i = 0; i < 2; i++) {
			ghostEnemy[i] = Game.spritesheet.getSprite(144, 0+(i*16), 16, 16);
		}
	}
	
	public void tick() {
		
		depth = 0;
		if(ghostMode == false) { //&& Player.GhostOn == false
			if(!isColiddingWithPlayer()) {
				if(path == null || path.size() == 0) {
					Vector2i start = new Vector2i((int)(x/16),(int)(y/16));
					Vector2i end = new Vector2i((int)(Game.player.x/16),(int)(Game.player.y/16));
					path = AStar.findPath(Game.world, start, end);
				}
			}else {
				Game.player.isDamaged = true;
				Game.gameState = "GAME_OVER";
				System.out.println("Game Over");
			}
			
			if(new Random().nextInt(100) < 80)
				followPath(path);
			
			if(x % 16 == 0 && y % 16 == 0) {
				if(new Random().nextInt(100) < 10) {
					Vector2i start = new Vector2i(((int)(x/16)),((int)(y/16)));
					Vector2i end = new Vector2i(((int)(Game.player.x/16)),((int)(Game.player.y/16)));
					path = AStar.findPath(Game.world, start, end);
					}
				}
			}
			ghostFrames++;
			modeGhost();
			if(ghostMode == false && ghostFrames >= 60) {
				ghostFrames = 0;
				
			}
			
			
			frames++;
			if(frames == maxFrames) {
				frames = 0;
				index++;
				if(index > maxIndex) {
					index = 0;
				}
			}
			
	}
	
	public void modeGhost() {
		if(ghostMode == true) {
			if(ghostFrames == 60*4) {
				ghostFrames = 0;
				ghostMode = false;
			}
			
		}
		
	}
	public boolean isColiddingWithPlayer() {
		
		Rectangle enemyCurrent = new Rectangle(this.getX(), this.getY(), World.TILE_SIZE, World.TILE_SIZE);
		Rectangle player = new Rectangle(Game.player.getX(), Game.player.getY(),16,16);
		return enemyCurrent.intersects(player);
	}
	
		public void render(Graphics g) {
			super.render(g);
			if(ghostMode == true) {
				g.drawImage(ghostEnemy[index], this.getX(), this.getY(),null);
			}
		}
	

}
