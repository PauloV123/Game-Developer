package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;


public class Enemy extends Entity{
	public double life = 3;
	public static BufferedImage[] ENEMY;
	private int frames = 0, maxFrames = 20, index = 0, maxIndex = 3;
	public Enemy(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		ENEMY = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			ENEMY[i] = Game.spritesheet.getSprite(32, 0+(i*19), 19, 19);
		}
	}
	
	public void tick() {
		frames++;
		if(frames == maxFrames) {
			frames = 0;
			index++;
			if(index > maxIndex) {
				index = 0;
			}
		}
		
		y+=speed;
		if(y>= Game.HEIGHT) {
			Game.entities.remove(this);
			Game.lifeT--;
			if(Game.lifeT == 0) {
				Game.lifeT = 0;
			}
			return;
		}
		
		for(int i = 0;i < Game.entities.size();i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof LaserShoot) {
				if(Entity.isColidding(this, e)) {
					Game.entities.remove(e);
					life--;
					if(life == 0) {
						Explosion explosion = new Explosion(x,y,28,28,0,null);
						Game.score += 50;
						Game.entities.remove(this);
						Game.entities.add(explosion);
						return;
					}
					break;
				}
			}
		}
	}
public void render(Graphics g) {
		
		g.drawImage(ENEMY[index], this.getX() - Camera.x, this.getY() - Camera.y,null);
		
	}
	
}
