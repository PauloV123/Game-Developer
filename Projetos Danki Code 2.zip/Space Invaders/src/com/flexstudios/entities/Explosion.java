package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;

public class Explosion extends Entity{
	public static BufferedImage[] EXPLOSION;
	private int frames = 0, maxFrames = 2, index = 0, maxIndex = 3;
	public Explosion(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		EXPLOSION = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			EXPLOSION[i] = Game.spritesheet.getSprite(51, 0+(i*28), 28, 28);
		}
	}
	public void tick() {
		frames++;
		if(frames == maxFrames) {
			frames = 0;
			index++;
			if(index > maxIndex) {
				index = 0;
				Game.entities.remove(this);
				return;
			}
		}
	}
	public void render(Graphics g) {
		g.drawImage(EXPLOSION[index], this.getX() - Camera.x, this.getY() - Camera.y,null);
	}
}
