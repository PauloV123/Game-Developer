package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;

import java.awt.Color;


public class LaserShoot extends Entity{

	public LaserShoot(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		
	}
	
	public void tick() {
		y-=speed;
		if(y<0) {
			Game.entities.remove(this);
			return;
		}
	}
	
	public void render(Graphics g) {
		g.setColor(Color.green);
		g.fillRect(this.getX()+2, this.getY(), width-1, height+5);
		g.setColor(Color.green);
		g.fillRect(this.getX()+18, this.getY(), width-1, height+5);
	}

}
