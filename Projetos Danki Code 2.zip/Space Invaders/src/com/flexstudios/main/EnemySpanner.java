package com.flexstudios.main;

import com.flexstudios.entities.Enemy;
import com.flexstudios.entities.Entity;

public class EnemySpanner {
	public int targetTime = 60*2;
	public int curTime = 0;
	
	public void tick() {
		curTime++;
		if(curTime==targetTime) {
			curTime = 0;
			int yy = 0;
			int xx = Entity.rand.nextInt(Game.WIDTH-16);
			Enemy enemy = new Enemy(xx,yy,19,19,Entity.rand.nextInt(1)+1,null);
			Game.entities.add(enemy);
		}
	}
}
