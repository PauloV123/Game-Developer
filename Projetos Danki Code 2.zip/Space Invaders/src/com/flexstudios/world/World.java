package com.flexstudios.world;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import com.flexstudios.entities.Enemy;
import com.flexstudios.entities.Entity;
import com.flexstudios.entities.Player;
import com.flexstudios.graficos.Spritesheet;
import com.flexstudios.graficos.UI;
import com.flexstudios.main.Game;

public class World{

	public static Tile[] tiles;
	public static int WIDTH, HEIGHT;
	public static final int TILE_SIZE = 16;
	public static int day = 0;
	public static int night = 1;	
	public static int CICLO = day;
	public World() {
		
		/*String[] tilesTypes = {"grass", "snow", "desert"};
		WIDTH = 1000;
		HEIGHT = 80;
		//Divisor do mapa
		int division = WIDTH/tilesTypes.length;
		tiles = new Tile[WIDTH*HEIGHT];
		for(int xx = 0; xx < WIDTH;xx++) {
			int initialHeight = Entity.rand.nextInt(20 - 17)+17;
			for(int yy = 0; yy<HEIGHT;yy++) {
				if(yy == HEIGHT -1|| xx == WIDTH -1 || xx == 0 || yy == 0) {
					tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_STONE);
					tiles[xx+yy*WIDTH].solid = true;
				}else {
					if(yy>=initialHeight) {
						int indexBioma = xx / division;
						if(tilesTypes[indexBioma] == "grass") {
							tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_GRASS);
							if(yy-1 >= 0 &&  tiles[xx+((yy-1)*WIDTH)] instanceof WallFile) {
								tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_DIRT);
							}
							if(yy-1 >= 0 &&  tiles[xx+((yy-4)*WIDTH)] instanceof WallFile) {
								tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_STONE);
								
							}
						}else if(tilesTypes[indexBioma] == "snow") {
							tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_SNOW);
							if(yy-1 >= 0 &&  tiles[xx+((yy-1)*WIDTH)] instanceof WallFile) {
								tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_DIRT);
							}
							if(yy-1 >= 0 &&  tiles[xx+((yy-4)*WIDTH)] instanceof WallFile) {
								tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_STONE);
								
							}
						}else if(tilesTypes[indexBioma] == "sand") {
							tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_SAND);
							if(yy-1 >= 0 &&  tiles[xx+((yy-1)*WIDTH)] instanceof WallFile) {
								tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_SAND);
							}
							if(yy-1 >= 0 &&  tiles[xx+((yy-4)*WIDTH)] instanceof WallFile) {
								tiles[xx+yy*WIDTH] = new WallFile(xx*16,yy*16,Tile.TILE_STONE);
								
							}
						}
						
					}else {
						tiles[xx+yy*WIDTH] = new FloorTile(xx*16,yy*16,Tile.TILE_PNG);
					}
					
				}
			}
		}
		 */
	}
	
	
	
	public static boolean isFree(double xNext, double yNext) {
		double x1 = xNext / TILE_SIZE;
		double y1 = yNext / TILE_SIZE;
		
		double x2 = (xNext+TILE_SIZE-1) / TILE_SIZE;
		double y2 = yNext / TILE_SIZE;
		
		double x3 = xNext / TILE_SIZE;
		double y3 = (yNext+TILE_SIZE-1) / TILE_SIZE;
		
		double x4 = (xNext+TILE_SIZE-1) / TILE_SIZE;
		double y4 = (yNext+TILE_SIZE-1) / TILE_SIZE;
		
		return !((tiles[(int)x1 + ((int)y1*World.WIDTH)] instanceof WallFile) || 
				(tiles[(int)x2 + ((int)y2*World.WIDTH)] instanceof WallFile) ||
				(tiles[(int)x3 + ((int)y3*World.WIDTH)] instanceof WallFile) ||
				(tiles[(int)x4 + ((int)y4*World.WIDTH)] instanceof WallFile));
	}
	
	public static void restartGame() {
		//TO DO: Aplicar m�todo de reiniciar o jogo corretamente
		return;
	}
	
	public void render(Graphics g) {
		int xstart = Camera.x >> 4; // ou /16
		int ystart = Camera.y >> 4; // ou /16
		
		int xfinal = xstart + (Game.WIDTH >> 4); // ou /16
		int yfinal = ystart + (Game.HEIGHT >> 4); // ou /16
		
		for(int xx = xstart; xx <= xfinal; xx++) {
			for(int yy = ystart; yy <= yfinal; yy++) {
				if(xx < 0 || yy < 0 || xx >= WIDTH || yy >= HEIGHT) {
					continue;
				}
				Tile tile = tiles[xx + (yy*WIDTH)];
				tile.render(g);
			}
		}
	}
	
	
	public static void main(String[] args) {

	}

}
