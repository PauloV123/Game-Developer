package com.flexstudios.world;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.entities.Entity;
import com.flexstudios.main.Game;

public class FloorTile extends Tile{

	public FloorTile(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);

	}
	


}
