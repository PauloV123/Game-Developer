package com.flexstudios.graficos;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.entities.Entity;
import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;

//import com.flexstudios.entities.Player;


public class UI {
	
	public void render(Graphics g) {
		
		g.drawImage(Entity.faceLife, 10, World.HEIGHT/2,40,40,null);
		g.setFont(new Font("arial", Font.BOLD, 20));
		g.setColor(Color.black);
		g.drawString("x"+((int)Game.player.lifeP), 55, (World.HEIGHT+65)/2);
	}
	

}
