package com.flexstudios.world;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

import com.flexstudios.entities.Coin;
import com.flexstudios.entities.Egg;
import com.flexstudios.entities.Enemy;
import com.flexstudios.entities.Entity;
import com.flexstudios.entities.Player;
import com.flexstudios.entities.Princess;
import com.flexstudios.graficos.Spritesheet;
import com.flexstudios.main.Game;

public class World{

	public static Tile[] tiles;
	public static int WIDTH, HEIGHT;
	public static final int TILE_SIZE = 16;
	
	public World(String path) {
		
		try {
			BufferedImage map = ImageIO.read(getClass().getResource(path));
			int[] pixels = new int[map.getWidth()*map.getHeight()];
			WIDTH = map.getWidth();
			HEIGHT = map.getHeight();
			tiles = new Tile[map.getWidth()*map.getHeight()];
			map.getRGB(0, 0, map.getWidth(), map.getHeight(), pixels, 0, map.getWidth());
			for(int xx = 0; xx< map.getWidth(); xx++) {
				for(int yy = 0; yy < map.getHeight(); yy++) {
					int pixelAtual = pixels[xx + (yy * map.getWidth())];
					tiles[xx + (yy*WIDTH)] = new FloorTile(xx*16, yy*16, Tile.TILE_FLOOR);
					if(pixelAtual == 0xFF000000) {
						//tiles[xx+(yy*WIDTH)] = null;
						tiles[xx + (yy*WIDTH)] = new FloorTile(xx*16, yy*16, Tile.TILE_FLOOR);
						
					}else if(pixelAtual == 0xFFffffff) {
						tiles[xx + (yy*WIDTH)] = new WallFile(xx*16, yy*16, Tile.TILE_WALL);
						if(yy-1 >= 0 && pixels[xx+((yy-1) * map.getWidth())] == 0xFFffffff) {
							tiles[xx + (yy * WIDTH)] = new WallFile(xx*16,yy*16,Game.spritesheet.getSprite(16, 16, 16, 16));
						}
					}else if(pixelAtual == 0xFF0026FF) {
						//PLAYER
						Game.player.setX(xx*16);
						Game.player.setY(yy*16);
					}else if(pixelAtual == 0xFFFF7E2D) {
						tiles[xx + (yy*WIDTH)] = new WallFile(xx*16, yy*16, Tile.TILE_WALL2);
					}else if(pixelAtual == 0xFFFF1924) {
						Enemy enemy = new Enemy(xx*16, yy*16,16,16,0.7, Entity.ENEMY1_SPRITE);
						Game.entities.add(enemy);
					}else if(pixelAtual == 0xFFFFE526) {
						//Coin
						Coin coin = new Coin(xx*16, yy*16,16,16,0, Entity.COIN_SPRITE);
						Game.entities.add(coin);
						Player.maxCoins++;
					}else if(pixelAtual == 0xFF22FF1E) {
						tiles[xx + (yy*WIDTH)] = new WallFile(xx*16, yy*16, Tile.TILE_BOX);
					}else if(pixelAtual == 0xFF30FFD9) {
						Egg egg = new Egg(xx*16, yy*16,16,16,0, Entity.EGG_SPRITE);
						Game.entities.add(egg);
					}
					else if(pixelAtual == 0xFFFF02C8) {
						Princess princess = new Princess(xx*16, (yy*16)-16,18,33,0, Entity.PRINCESS_SPRITE);
						Game.entities.add(princess);
					}
					
				}			
			}
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	
	public static boolean isFree(double xNext, double yNext) {
		double x1 = xNext / TILE_SIZE;
		double y1 = yNext / TILE_SIZE;
		
		double x2 = (xNext+TILE_SIZE-1) / TILE_SIZE;
		double y2 = yNext / TILE_SIZE;
		
		double x3 = xNext / TILE_SIZE;
		double y3 = (yNext+TILE_SIZE-1) / TILE_SIZE;
		
		double x4 = (xNext+TILE_SIZE-1) / TILE_SIZE;
		double y4 = (yNext+TILE_SIZE-1) / TILE_SIZE;
		
		return !((tiles[(int)x1 + ((int)y1*World.WIDTH)] instanceof WallFile) || 
				(tiles[(int)x2 + ((int)y2*World.WIDTH)] instanceof WallFile) ||
				(tiles[(int)x3 + ((int)y3*World.WIDTH)] instanceof WallFile) ||
				(tiles[(int)x4 + ((int)y4*World.WIDTH)] instanceof WallFile));
	}
	
	public static void restartGame() {
		//TO DO: Aplicar m�todo de reiniciar o jogo corretamente
		return;
	}
	
	public void render(Graphics g) {
		int xstart = Camera.x >> 4; // ou /16
		int ystart = Camera.y >> 4; // ou /16
		
		int xfinal = xstart + (Game.WIDTH >> 4); // ou /16
		int yfinal = ystart + (Game.HEIGHT >> 4); // ou /16
		
		for(int xx = xstart; xx <= xfinal; xx++) {
			for(int yy = ystart; yy <= yfinal; yy++) {
				if(xx < 0 || yy < 0 || xx >= WIDTH || yy >= HEIGHT) {
					continue;
				}
				Tile tile = tiles[xx + (yy*WIDTH)];
				tile.render(g);
			}
		}
	}
	
	
	public static void main(String[] args) {

	}

}
