package com.flexstudios.entities;

import java.awt.image.BufferedImage;

public class Egg extends Entity{

	public Egg(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
	}

}
