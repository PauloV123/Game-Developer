package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;

public class Coin extends Entity {
	private int frames = 0, maxFrames = 20, index = 0, maxIndex = 1;
	private BufferedImage[] coinAnimation;
	public Coin(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		coinAnimation = new BufferedImage[2];
		for(int i = 0; i < 2; i++) {
			coinAnimation[i] = Game.spritesheet.getSprite(16, 32+(i*16), 16, 16);
		}
	}
	public void tick() {
		frames++;
		if(frames == maxFrames) {
			frames = 0;
			index++;
			if(index > maxIndex) {
				index = 0;
			}
		}
	}
	public void render(Graphics g) {
		g.drawImage(coinAnimation[index], this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
	}

}
