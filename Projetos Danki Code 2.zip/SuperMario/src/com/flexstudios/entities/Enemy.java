package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;

public class Enemy extends Entity{
	
	public int life1 = 1;

	
	public static BufferedImage[] ENEMY;
	private int frames = 0, maxFrames = 20, index = 0, maxIndex = 1;
	public boolean right = true, left = false;
	public Enemy(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		ENEMY = new BufferedImage[2];
		for(int i = 0; i < 2; i++) {
			ENEMY[i] = Game.spritesheet.getSprite(48, 32+(i*16), 16, 16);
		}
	}
	
	public void tick() {
		
		frames++;
		
			if(frames == maxFrames) {
				frames = 0;
				index++;
				if(index > maxIndex) {
					index = 0;
				}
			}
			if(World.isFree((int)x, (int)(y+2))) {
				y+=2;
				
			}
			if(right && World.isFree((int)(x+speed), (int)y)) {
				x+=speed;
				if(World.isFree((int)(x+16), (int)y+1)) {
					right = false;
					left = true;
					
				}
			}else {
				right = false;
				left = true;
			}
			if(left && World.isFree((int)(x-speed), (int)y)) {
				x-=speed;
				if(World.isFree((int)(x-16), (int)y+1)) {
					right = true;
					left = false;
					
				}
			}else {
				right = true;
				left = false;
			}
		
		
		
		
	}
	public void render(Graphics g) {
		
		g.drawImage(ENEMY[index], this.getX() - Camera.x, this.getY() - Camera.y,null);
		
		/*else if(Player.GoombaDie) {
			g.drawImage(Entity.ENEMY1DIE_SPRITE, this.getX() - Camera.x, this.getY() - Camera.y,null);
		}*/
	}
	
}
