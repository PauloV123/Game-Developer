package com.flexstudios.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;


public class Player extends Entity {
	private BufferedImage[] rightPlayer;
	private BufferedImage[] leftPlayer;
	private BufferedImage jumpRight;
	private BufferedImage jumpLeft;
	public static boolean GoombaDie = false;
	private boolean moved = false;
	public boolean stopped = true;
	public boolean isJumping = false;
	public boolean jump = false;
	public int jumpHeight = 50;
	public int jumpFrames = 0;
	public int dir = 1;
	public double lifeP = 10;
	public int enemyDieFrame = 0;
	private int frames = 0, maxFrames = 10, index = 0, maxIndex = 1;
	public boolean right, left,up;
	private int gravity = 2;
	public static boolean marioDead = false;
	public static boolean hasEgg = false;
	public static int currentCoin = 0;
	public static int maxCoins = 0;
	private BufferedImage[] rightPlayerWithYoshi;
	private BufferedImage[] leftPlayerWithYoshi;
	public Player(int x, int y, int width, int height,double speed ,BufferedImage sprite) {
		super(x, y, width, height,speed, sprite);
		rightPlayer = new BufferedImage[2];
		leftPlayer = new BufferedImage[2];
		rightPlayerWithYoshi = new BufferedImage[2];
		leftPlayerWithYoshi = new BufferedImage[2];
		for(int i = 0; i < 2; i++) {
			rightPlayer[i] = Game.spritesheet.getSprite(80, 0+(i*20), 16, 20);
		}
		for(int i = 0; i < 2; i++) {
			leftPlayer[i] = Game.spritesheet.getSprite(96, 0+(i*20), 16, 20);
		}
		for(int i = 0; i < 2; i++) {
			rightPlayerWithYoshi[i] = Game.spritesheet.getSprite(112, 0+(i*38), 27, 38);
		}
		for(int i = 0; i < 2; i++) {
			leftPlayerWithYoshi[i] = Game.spritesheet.getSprite(112, 76+(i*38), 27, 38);
		}
		jumpRight = Game.spritesheet.getSprite(80, 40, 16, 22);
		jumpLeft = Game.spritesheet.getSprite(96, 40, 16, 22);
	}
	
	public void tick() {
		depth = 2;
		moved = false;
		if(!marioDead) {
			if(World.isFree((int)x, (int)(y+speed))&& isJumping == false) {
				y+=gravity;
				for(int i = 0; i < Game.entities.size(); i++) {
					Entity e = Game.entities.get(i);
					if(e instanceof Enemy) {
						if(Entity.isColidding(this, e)) {
							//Matando o inimigo
							isJumping = true;
							jumpHeight = 56;
							//GoombaDie = true;
							//remo��o da vida do inimigo
							((Enemy) e).life1--;
							if(((Enemy) e).life1 == 0) {
								//Destruir o inimigo
								Game.entities.remove(i);
								break;
							}
						}
					}
					
				}
					
			}
			if(right && World.isFree((int)x+speed, (int)y)) {
				x+=speed;
				dir = 1;
				moved = true;
				stopped = false;
				
			}else if(left && World.isFree((int)x-speed, (int)y)) {
				x-=speed;
				dir = 2;
				moved = true;
				stopped = false;
			}
			
			if(moved) {
				frames++;
				if(frames == maxFrames) {
					frames = 0;
					index++;
					if(index > maxIndex) {
						index = 0;
					}
				}
			}
			if(jump) {
	
				if(!World.isFree(this.getX(), this.getY()+1)) {
					isJumping = true;
		
				}else {
					jump = false;
				
				}
			}
			if(isJumping) {
				if(World.isFree(this.getX(), this.getY()-2)) {
					y-=2;
					jumpFrames+=2;
					if(jumpFrames == jumpHeight) {
						isJumping=false;
						jump = false;
						jumpFrames = 0;
					}
				}else {
					isJumping = false;
					jump = false;
					jumpFrames = 0;
				}
			}
		}
		
		//Detectar colis�o com a moeda
		for(int i = 0; i < Game.entities.size(); i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof Coin) {
				if(Entity.isColidding(this, e)) {
					Game.entities.remove(e);
					
					break;
				}
			}
			
		}
		checkCollisionEgg();
		checkCollisionPrincess();
		Camera.x = Camera.clamp((int)x - Game.WIDTH/2, 0, World.WIDTH*16);
		Camera.y = Camera.clamp((int)y - Game.HEIGHT/2, 0, World.HEIGHT*16 - Game.HEIGHT);
		
		
		//Detectar dano
		for(int i = 0; i < Game.entities.size(); i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof Enemy) {
				if(Entity.isColidding(this, e)) {
					lifeP--;
					//resetar o game
					if(lifeP < 0) {
						lifeP = 0;
						marioDead = true;
						Game.gameState = "GAME_OVER";
					}
					
				}
			}
			
		}
		
	}
	public void checkCollisionEgg() {
		for(int i = 0; i < Game.entities.size(); i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof Egg) {
				if(Entity.isColidding(this, e)) {
					hasEgg = true;
					Game.entities.remove(i);
					return;
				}
			}
		}

	}
	public void checkCollisionPrincess() {
		for(int i = 0; i < Game.entities.size(); i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof Princess) {
				if(Entity.isColidding(this, e)) {
					Game.entities.remove(i);
					Game.CUR_LEVEL++;
					return;
				}
			}
		}

	}

	public void render(Graphics g) {
		if(!marioDead && !hasEgg){
			if(!stopped && isJumping == false) {
				if(dir == 1) {
					g.drawImage(rightPlayer[index], this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
					
				}else if(dir == 2) {
					g.drawImage(leftPlayer[index], this.getX()- Camera.x, this.getY()-4- Camera.y,null);
					
				}
			}
			if(isJumping && dir == 1) {
				g.drawImage(jumpRight, this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
			}else if(isJumping && dir == 2) {
				g.drawImage(jumpLeft, this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
			}
			if(stopped && isJumping == false) {
				if(dir == 1) {
					g.drawImage(Entity.PLAYER_SPRITE, this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
				}else if(dir == 2) {
					g.drawImage(Entity.PLAYER_SPRITE2, this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
				}
				
			}
		}else if(hasEgg && !marioDead){
			if(dir == 1) {
				g.drawImage(rightPlayerWithYoshi[index], this.getX() - Camera.x, this.getY()-12- Camera.y,20,30,null);
				
			}else if(dir == 2) {
				g.drawImage(leftPlayerWithYoshi[index], this.getX()- Camera.x, this.getY()-12- Camera.y,20,30,null);
				
			}
		}
		if(marioDead){
			g.drawImage(Entity.PLAYERDIE_SPRITE, this.getX() - Camera.x, this.getY()-4 - Camera.y,null);
		}
	}
	


}
