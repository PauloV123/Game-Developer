package com.flexstudios.entities;

import java.awt.image.BufferedImage;

public class Princess extends Entity{

	public Princess(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
	}

}
