package com.flexstudios.world;

import com.flexstudios.entities.Back;
import com.flexstudios.main.Game;

public class BackGenerator {
	public int time = 0;

	
	public void tick() {
		time++;
		if(time == 20) {
			time=0;
			
			Back back2 = new Back(Game.WIDTH,Game.HEIGHT,20,0,1,Game.spritesheet.getSprite(16, 0, 32,16));
			Game.entities.add(back2);
			
		}
	}
}
