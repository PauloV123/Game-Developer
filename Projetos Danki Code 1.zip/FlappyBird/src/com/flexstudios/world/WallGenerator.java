package com.flexstudios.world;



import java.awt.image.BufferedImage;

import com.flexstudios.entities.Back;
import com.flexstudios.entities.Entity;
import com.flexstudios.entities.Wall;
import com.flexstudios.main.Game;

public class WallGenerator{
	public int time = 0;
	public void tick() {
		time++;
		if(time == 60) {
			//tubo novo e reseta o contador.
			time = 0;
			int altura1 = Entity.rand.nextInt(70 - 30) + 30;
			Wall wall1 = new Wall(Game.WIDTH,0,20,altura1,1,Game.spritesheet.getSprite(16, 16, 16,16));
			
			Game.entities.add(wall1);
			
			int altura2 = Entity.rand.nextInt(70 - 30) + 30;
			Wall wall2 = new Wall(Game.WIDTH,Game.HEIGHT- altura2,20,altura2,1,Game.spritesheet.getSprite(16, 16, 16,16));
			
			
			Game.entities.add(wall2);

		}else if(time == 20){
			time = 21;
			Back back2 = new Back(Game.WIDTH,Game.HEIGHT-54,45,60,1,Game.spritesheet.getSprite(16, 0, 32,16));
			Game.entities.add(back2);
		}
	}
	
	
}
