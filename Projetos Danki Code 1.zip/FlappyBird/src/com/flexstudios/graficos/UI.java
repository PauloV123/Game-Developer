package com.flexstudios.graficos;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import com.flexstudios.main.Game;

//import com.flexstudios.entities.Player;


public class UI {

	public void render(Graphics g) {
		//placar cos points
		g.setColor(Color.white);
		g.setFont(new Font("arial", Font.BOLD,18));
		g.drawString("Score: "+(int)Game.score, 20, 20);
	}
	
	public static void main(String[] args) {
	
	}

}
