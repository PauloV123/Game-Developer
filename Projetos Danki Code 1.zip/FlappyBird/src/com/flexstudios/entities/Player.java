package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;


public class Player extends Entity {
	public boolean dead = false;
	public boolean isPressed = false;
	private BufferedImage fly;
	public Player(int x, int y, int width, int height,double speed ,BufferedImage sprite) {
		super(x, y, width, height,speed, sprite);
		fly = Game.spritesheet.getSprite(0, 16, 16, 16);	
	}
	
	public void tick() {
		depth = 2;
		if(!isPressed) {
			y+=2;
		}else {
			if(y>0) {
				y-=2;
			}
		}
		
		if(y > Game.HEIGHT) {
			Game.gameState = "GAME_OVER";
			dead = true;
		}
		
		//colisao
		for(int i = 0; i < Game.entities.size();i++) {
			Entity e = Game.entities.get(i);
			if(e != this) {
				if(Entity.isColidding(this, e)) {
					//Game Over
					Game.gameState = "GAME_OVER";
					dead = true;
					//World.restartGame();
					//return;
				}
			}
		}
		
	}

	public void render(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
			if(!isPressed) {
				g2.rotate(Math.toRadians(20),this.getX()+width/2, this.getY()+height/2);
				g2.drawImage(sprite, this.getX(), this.getY(), null);
				g2.rotate(Math.toRadians(-20),this.getX()+width/2, this.getY()+height/2);
			}else {
				g2.rotate(Math.toRadians(-20),this.getX()+width/2, this.getY()+height/2);
				g2.drawImage(fly, this.getX(), this.getY(), null);
				g2.rotate(Math.toRadians(20),this.getX()+width/2, this.getY()+height/2);
			}
			
		
	
		
		
		
	}
	


}
