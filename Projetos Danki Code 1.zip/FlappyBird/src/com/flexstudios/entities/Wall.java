package com.flexstudios.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;


public class Wall extends Entity{

	public Wall(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
	}
	public void tick() {
		if(Game.player.dead == false){
			x--;
			if(x+width <= 0) {
				Game.score += 0.5;
				Game.entities.remove(this);
				return;
			}
		}
		
	}
	public void render(Graphics g) {
		if(sprite != null) {
			g.drawImage(sprite, this.getX(), this.getY(),width, height,null);
		}else {
			g.setColor(Color.orange);
			g.fillRect(this.getX(), this.getY(),width, height);
		}
		
	}
}
