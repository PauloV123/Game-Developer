import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Smoke {
	public int x,y;
	public static BufferedImage[] crabSmoke;
	private int frames = 0, maxFrames = 10, index = 0, maxIndex = 1;
	public Smoke(int x, int y) {
		this.x = x;
		this.y = y;
		crabSmoke = new BufferedImage[2];
		for(int i = 0; i < 2; i++) {
			crabSmoke[i] = Game.spritesheet.getSprite(32+(i*16), 0);
		}
	}
	
	public void update() {
		frames++;
		if(frames == maxFrames) {
			frames = 0;
			index++;
			if(index > maxIndex) {
				index = 0;
				Game.smokes.remove(this);
			}
		}
	}
	
	public void render(Graphics g) {
		g.drawImage(crabSmoke[index],(int)x,(int)y,50,50,null);
	}
}
