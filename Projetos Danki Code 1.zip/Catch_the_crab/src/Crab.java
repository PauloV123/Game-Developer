import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;



public class Crab {
	public static BufferedImage[] crabSprite;
	public double x,y,dx,dy;
	public double speed = 4;
	private int frames = 0, maxFrames = 10, index = 0, maxIndex = 1;
	public Crab(int x, int y) {
		this.x = x;
		this.y = y;
		double radius = Math.atan2((Game.HEIGHT/2 -20) - y, (Game.WIDTH/2 -20) - x);
		this.dx = Math.cos(radius);
		this.dy = Math.sin(radius);
		crabSprite = new BufferedImage[2];
		for(int i = 0; i < 2; i++) {
			crabSprite[i] = Game.spritesheet.getSprite(0+(i*16), 0);
		}
		
	}
	
	public void update() {
		x+=(dx*speed);
		y+=(dy*speed);
		
		frames++;
		if(frames == maxFrames) {
			frames = 0;
			index++;
			if(index > maxIndex) {
				index = 0;
			}
		}
		if(new Rectangle((int)x,(int)y,40,40).intersects(Game.maskHole)) {
			Game.crabs.remove(this);
			return;
		}
		//Verificando colisao com pontos do mouse
		mouseCollision();
	}
	
	public void mouseCollision() {
		if(Game.isPressed) {
			Game.isPressed = false;
			if(Game.mx >= x && Game.mx <= x +40) {
				if(Game.my >= y && Game.my <= y +40) {
					Game.crabs.remove(this);
					Game.score+=20;
					Game.smokes.add(new Smoke((int)x,(int)y));
					return;
				}
			}
		}
	}
	public void render(Graphics g) {
		g.drawImage(crabSprite[index],(int)x,(int)y,50,50,null);
		/*g.setColor(Color.red);
		g.fillRect((int)x, (int)y,40, 40);*/
	}
}
