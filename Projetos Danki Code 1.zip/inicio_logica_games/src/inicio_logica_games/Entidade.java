package inicio_logica_games;

public class Entidade {
	private int vida;
	private int x, y;
	public Entidade() {
		
	}
	/*public static void main(String[] args) {
		

	}*/

}
