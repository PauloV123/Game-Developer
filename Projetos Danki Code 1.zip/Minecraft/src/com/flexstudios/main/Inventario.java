package com.flexstudios.main;

import java.awt.Color;
import java.awt.Graphics;

import com.flexstudios.world.Camera;
import com.flexstudios.world.FloorTile;
import com.flexstudios.world.Tile;
import com.flexstudios.world.WallFile;
import com.flexstudios.world.World;

public class Inventario {
		
		public int inventoryBoxSize = 40;
		public static boolean placedSword = false;
		public String[] itens = {"dirt", "grass", "snow","stone","sword" ,"", "", "", "", "", "", "remove"};
		public int initialPosition = ((Game.WIDTH * Game.SCALE)/2 )- ((itens.length *inventoryBoxSize)/2);
		public int selected = 0;
		public boolean isPressed = false;
		public int mx, my;
		public boolean isPlaceItem = false;
		public void tick() {
			if(isPressed) {
				isPressed = false;
				if(mx >= initialPosition && mx < initialPosition + (inventoryBoxSize*itens.length)) {
					if(my >= Game.HEIGHT*Game.SCALE-inventoryBoxSize-1 && my < Game.HEIGHT*Game.SCALE-inventoryBoxSize-1 + inventoryBoxSize) {
						selected = (int)(mx - initialPosition) / inventoryBoxSize;
					}
				}
			}
			
			if(isPlaceItem) {
				isPlaceItem = false;
				mx = (int)mx/3 + Camera.x;
				my = (int)my/3 + Camera.y;
				placedSword = false;
				int tileX = mx/16;
				int tileY = my/16;
				if(World.tiles[tileX+tileY*World.WIDTH].solid == false) {
					if(itens[selected] == "grass") {
						World.tiles[tileX+tileY*World.WIDTH] = new WallFile(tileX*16,tileY*16,Tile.TILE_GRASS);
					}else if(itens[selected] == "stone") {
						World.tiles[tileX+tileY*World.WIDTH] = new WallFile(tileX*16,tileY*16,Tile.TILE_STONE);
					}else if(itens[selected] == "snow") {
						World.tiles[tileX+tileY*World.WIDTH] = new WallFile(tileX*16,tileY*16,Tile.TILE_SNOW);
					}else if(itens[selected] == "remove") {
						World.tiles[tileX+tileY*World.WIDTH] = new FloorTile(tileX*16,tileY*16,Tile.TILE_PNG);
					}else if(itens[selected] == "dirt") {
						World.tiles[tileX+tileY*World.WIDTH] = new WallFile(tileX*16,tileY*16,Tile.TILE_DIRT);
					}else if(itens[selected] == "sword") {
						placedSword = true;
					}
					if(World.isFree(Game.player.getX(), Game.player.getY()) == false || World.isFree(Game.player.getX(), Game.player.getY()-16) == false) {
						World.tiles[tileX+tileY*World.WIDTH] = new FloorTile(tileX*16,tileY*16,Tile.TILE_PNG);
					}
					
					
					
				}
			}
		}
		public void render(Graphics g) {
			for(int i = 0; i < itens.length; i++) {
				g.setColor(Color.DARK_GRAY);
				g.fillRect(initialPosition+(i*inventoryBoxSize)+1,Game.HEIGHT*Game.SCALE-inventoryBoxSize-1,inventoryBoxSize,inventoryBoxSize);
				g.setColor(Color.GRAY);
				g.drawRect(initialPosition+(i*inventoryBoxSize)+1,Game.HEIGHT*Game.SCALE-inventoryBoxSize-1,inventoryBoxSize,inventoryBoxSize);
				if(itens[i] == "dirt") {
					g.drawImage(Tile.TILE_DIRT,initialPosition+(i*inventoryBoxSize)+7,Game.HEIGHT*Game.SCALE-inventoryBoxSize+6,29,29,null);
				}else if(itens[i] == "grass") {
					g.drawImage(Tile.TILE_GRASS,initialPosition+(i*inventoryBoxSize)+7,Game.HEIGHT*Game.SCALE-inventoryBoxSize+6,29,29,null);
				}else if(itens[i] == "snow") {
					g.drawImage(Tile.TILE_SNOW,initialPosition+(i*inventoryBoxSize)+7,Game.HEIGHT*Game.SCALE-inventoryBoxSize+6,29,29,null);
				}else if(itens[i] == "stone") {
					g.drawImage(Tile.TILE_STONE,initialPosition+(i*inventoryBoxSize)+7,Game.HEIGHT*Game.SCALE-inventoryBoxSize+6,29,29,null);
				}else if(itens[i] == "remove") {
					g.drawImage(Tile.TILE_REMOVE,initialPosition+(i*inventoryBoxSize)+7,Game.HEIGHT*Game.SCALE-inventoryBoxSize+2,29,29,null);
				}else if(itens[i] == "sword") {
					g.drawImage(Tile.TILE_SWORD,initialPosition+(i*inventoryBoxSize)+7,Game.HEIGHT*Game.SCALE-inventoryBoxSize+2,29,35,null);
				}
				if(selected == i) {
					g.setColor(Color.blue);
					g.drawRect(initialPosition+(i*inventoryBoxSize),Game.HEIGHT*Game.SCALE-inventoryBoxSize-1,inventoryBoxSize,inventoryBoxSize);
				}
			}
		}
}
