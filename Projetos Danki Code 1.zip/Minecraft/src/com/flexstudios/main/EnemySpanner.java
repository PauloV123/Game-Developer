package com.flexstudios.main;

import com.flexstudios.entities.Enemy;
import com.flexstudios.entities.Entity;
import com.flexstudios.world.World;

public class EnemySpanner {
	
	public int interval = 60*10;
	public int curTime = 0;
	public void tick() {
		curTime++;
		if(curTime == interval) {
			curTime = 0;
			int xInitial = Entity.rand.nextInt(World.WIDTH*16 - 16 - 16)+16;
			Enemy enemy = new Enemy(xInitial,50,16,30,0.7,Entity.ENEMY_SPRITE);
			Game.entities.add(enemy);
		}
	}
}
