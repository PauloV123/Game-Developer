package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.main.Inventario;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;


public class Player extends Entity {
	private BufferedImage rightPlayer[];
	private BufferedImage leftPlayer[];
	private BufferedImage rightPlayerSword[];
	private BufferedImage leftPlayerSword[];
	public BufferedImage attackRight;
	public BufferedImage attackRightPlayer;
	public BufferedImage attackLeft;
	public BufferedImage attackLeftPlayer;
	public boolean attack = false;
	public boolean isAttack = false;
	public int attackFrames = 0, maxFramesAttack=15;
	private boolean moved = false;
	public boolean stopped = true;
	public boolean isJumping = false;
	public boolean jump = false;
	public int jumpHeight = 50;
	public int jumpFrames = 0;
	public int dir = 1;
	public static double  life = 10;
	public int enemyDieFrame = 0;
	private int frames = 0, maxFrames = 10, index = 0, maxIndex = 3;
	public boolean right, left,up;
	private int gravity = 2;

	public Player(int x, int y, int width, int height,double speed ,BufferedImage sprite) {
		super(x, y, width, height,speed, sprite);

		rightPlayer = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			rightPlayer[i] = Game.spritesheet.getSprite(64, 0+(i*30), 16, 30);
		}
		leftPlayer = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			leftPlayer[i] = Game.spritesheet.getSprite(80, 0+(i*30), 16, 30);
		}
		rightPlayerSword = new BufferedImage[4];
		leftPlayerSword = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			rightPlayerSword[i] = Game.spritesheet.getSprite(32, 32+(i*30), 19, 30);
		}
		for(int i = 0; i < 4; i++) {
			leftPlayerSword[i] = Game.spritesheet.getSprite(128, 0+(i*30), 19, 30);
		}
		attackRight = Game.spritesheet.getSprite(16, 64, 16, 16);
		attackLeft = Game.spritesheet.getSprite(16, 80, 16, 16);
		attackRightPlayer = Game.spritesheet.getSprite(80, 122, 16, 31);
		attackLeftPlayer = Game.spritesheet.getSprite(64, 122, 16, 31);
	}
	
	public void tick() {
		depth = 2;
		moved = false;
	
			if(World.isFree((int)x, (int)(y+speed))&& isJumping == false) {
				y+=gravity;
					
			}
			if(right && World.isFree((int)x+speed, (int)y) && World.isFree(Game.player.getX(), Game.player.getY()-16)) {
				x+=speed;
				dir = 1;
				moved = true;
				stopped = false;
				
			}else if(left && World.isFree((int)x-speed, (int)y) && World.isFree(Game.player.getX(), Game.player.getY()-16)) {
				x-=speed;
				dir = 2;
				moved = true;
				stopped = false;
			}
			
			if(moved) {
				frames++;
				if(frames == maxFrames) {
					frames = 0;
					index++;
					if(index > maxIndex) {
						index = 0;
					}
				}
			}
			if(jump) {
	
				if(!World.isFree(this.getX(), this.getY()+1)) {
					isJumping = true;
		
				}else {
					jump = false;
				
				}
			}
			
			
			if(isJumping) {
				if(World.isFree(this.getX(), this.getY()-2)) {
					y-=2;
					jumpFrames+=2;
					if(jumpFrames == jumpHeight) {
						isJumping=false;
						jump = false;
						jumpFrames = 0;
					}
				}else {
					isJumping = false;
					jump = false;
					jumpFrames = 0;
				}
			}
		
			//Sistema de ataque
			
			if(attack) {
				if(isAttack == false && Inventario.placedSword) {
					attack = false;
					isAttack = true;
				}
			}
			if(isAttack) {
				attackFrames++;
				if(attackFrames == maxFramesAttack) {
					attackFrames = 0;
					isAttack = false;
				}
			}
			
		CollisionEnemy();
		Camera.x = Camera.clamp((int)x - Game.WIDTH/2, 0, World.WIDTH*16);
		Camera.y = Camera.clamp((int)y - Game.HEIGHT/2, 0, World.HEIGHT*16 - Game.HEIGHT);
		
		
	}
	
	public void CollisionEnemy(){
		for(int i = 0; i < Game.entities.size(); i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof Enemy) {
				if(Entity.isColidding(this, e)) {
					life-= 0.1;
					if(isAttack) {
						((Enemy) e).life1--;
						
					}
				}
				
			}
		}
	}

	public void render(Graphics g) {

			if(!stopped && isJumping == false) {
				if(dir == 1) {
					if(!Inventario.placedSword) {
						g.drawImage(rightPlayer[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
					}else if(Inventario.placedSword) {
						g.drawImage(rightPlayerSword[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
						if(isAttack) {
							g.drawImage(attackRight, this.getX()+8 - Camera.x, this.getY() - 14 - Camera.y,null);
						}
					}
					
					
				}else if(dir == 2) {
					if(!Inventario.placedSword) {
						g.drawImage(leftPlayer[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
					}else if(Inventario.placedSword) {
						g.drawImage(leftPlayerSword[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
						if(isAttack) {
							g.drawImage(attackLeft, this.getX()-8 - Camera.x, this.getY() - 14 - Camera.y,null);
						}
					}
					
				}
			}
			if(isJumping && dir == 1) {
				if(!Inventario.placedSword) {
					g.drawImage(rightPlayer[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
				}else if(Inventario.placedSword) {
					g.drawImage(rightPlayerSword[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
					if(isAttack) {
						g.drawImage(attackRight, this.getX()+8 - Camera.x, this.getY() - 14 - Camera.y,null);
					}
				}
			}else if(isJumping && dir == 2) {
				if(!Inventario.placedSword) {
					g.drawImage(leftPlayer[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
				}else if(Inventario.placedSword) {
					g.drawImage(leftPlayerSword[index], this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
					if(isAttack) {
						g.drawImage(attackLeft, this.getX()-8 - Camera.x, this.getY() - 14 - Camera.y,null);
					}
				}
			}
			if(stopped && isJumping == false) {
				if(dir == 1) {
					if(!Inventario.placedSword) {
						g.drawImage(Entity.PLAYER_SPRITE, this.getX() - Camera.x, this.getY()- 14 - Camera.y,null);
					}else if(Inventario.placedSword) {
						if(isAttack) {
							g.drawImage(attackRightPlayer, this.getX()+3 - Camera.x, this.getY() - 15 - Camera.y,null);
							g.drawImage(attackRight, this.getX()+8 - Camera.x, this.getY() - 14 - Camera.y,null);
						}else {
							g.drawImage(Entity.PLAYERSWORD_SPRITE, this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
						}
					}
					
				}else if(dir == 2) {
					if(!Inventario.placedSword) {
						g.drawImage(Entity.PLAYER_SPRITE2, this.getX() - Camera.x, this.getY()- 14 - Camera.y,null);
					}else if(Inventario.placedSword) {
						if(isAttack) {
							g.drawImage(attackLeftPlayer, this.getX()+1 - Camera.x, this.getY() - 15 - Camera.y,null);
							g.drawImage(attackLeft, this.getX()-8 - Camera.x, this.getY() - 14 - Camera.y,null);
						}else {
							g.drawImage(Entity.PLAYERSWORD_SPRITE2, this.getX() - Camera.x, this.getY() - 14 - Camera.y,null);
						}
					}
				}
				
			}
		
	}
	


}
