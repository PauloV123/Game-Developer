package com.flexstudios.entities;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;
import com.flexstudios.world.World;

public class Enemy extends Entity{
	
	public double life1 = 10;
	public static BufferedImage[] ENEMY_RIGHT;
	public static BufferedImage[] ENEMY_LEFT;
	private boolean moved = false;
	public int dir = 1;
	private int frames = 0, maxFrames = 20, index = 0, maxIndex = 3;
	public boolean right = true, left = false;
	public Enemy(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		ENEMY_RIGHT = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			ENEMY_RIGHT[i] = Game.spritesheet.getSprite(96, 0+(i*30), 16, 30);
		}
		ENEMY_LEFT = new BufferedImage[4];
		for(int i = 0; i < 4; i++) {
			ENEMY_LEFT[i] = Game.spritesheet.getSprite(112, 0+(i*30), 16, 30);
		}
	}
	
	public void tick() {
			if(moved) {
				frames++;
				
				if(frames == maxFrames) {
					frames = 0;
					index++;
					if(index > maxIndex) {
						index = 0;
					}
				}
			}
			
		
			if(World.isFree((int)x, (int)(y+2))) {
				y+=2;
				
			}
			if(dir == 1) {
				if(World.isFree((int)(x+speed), (int)y)&& World.isFree((int)x,(int)y -16)) {
					x+=speed;
					moved = true;
				}else{
					
					dir = 2;
				}
				
			}else if(dir == 2) {
				if(World.isFree((int)(x-speed), (int)y)&& World.isFree((int)x,(int)y -16)) {
					x-=speed;
					moved = true;
				}else {
					dir = 1;
				}
			}
		if(life1 == 0) {
			Game.entities.remove(this);
			return;
		}
		
	}
	public void render(Graphics g) {
		if(dir == 1) {
			g.drawImage(ENEMY_RIGHT[index], this.getX() - Camera.x, this.getY()-14 - Camera.y,null);
		}else if(dir == 2) {
			g.drawImage(ENEMY_LEFT[index], this.getX() - Camera.x, this.getY()-14 - Camera.y,null);
		}
		
		
		
	}
	
}
