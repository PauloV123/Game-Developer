package com.flexstudios.world;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.entities.Entity;
import com.flexstudios.main.Game;

public class FloorTile extends Tile{

	public FloorTile(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);

	}
	
	public void render(Graphics g) {
		if(World.CICLO == World.day) {
			g.drawImage(Tile.TILE_PNG, x - Camera.x, y - Camera.y, null);
			
		}else if(World.CICLO == World.night) {
			g.drawImage(Tile.TILE_PNG2, x - Camera.x, y - Camera.y, null);
			

		}
	}


}
