package com.flexstudios.world;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;

public class Tile {

	public static BufferedImage TILE_DIRT = Game.spritesheet.getSprite(0, 0, 16, 16);
	public static BufferedImage TILE_GRASS = Game.spritesheet.getSprite(16,0, 16, 16);
	public static BufferedImage TILE_STONE = Game.spritesheet.getSprite(32, 0, 16, 16);
	public static BufferedImage TILE_SNOW = Game.spritesheet.getSprite(48, 0, 16, 16);
	public static BufferedImage TILE_PNG = Game.spritesheet.getSprite(0, 16, 16, 16);
	public static BufferedImage TILE_REMOVE = Game.spritesheet.getSprite(16, 16, 16, 16);
	public static BufferedImage TILE_SAND = Game.spritesheet.getSprite(32, 16, 16, 16);
	public static BufferedImage TILE_PNG2 = Game.spritesheet.getSprite(0, 32, 16, 16);
	public static BufferedImage TILE_PNG3 = Game.spritesheet.getSprite(0, 48, 16, 16);
	public static BufferedImage TILE_PNG4 = Game.spritesheet.getSprite(0, 64, 16, 16);
	public static BufferedImage TILE_SWORD = Game.spritesheet.getSprite(16, 48, 16, 16);
	public boolean solid = false;
	private BufferedImage sprite;
	protected int x, y;
	
	public Tile(int x, int  y, BufferedImage sprite) {
		this.x = x;
		this.y = y;
		this.sprite = sprite;
	}
	
	public void render(Graphics g) {
		g.drawImage(sprite, x - Camera.x , y - Camera.y, null);
	}
	
	public static void main(String[] args) {

	}

}
