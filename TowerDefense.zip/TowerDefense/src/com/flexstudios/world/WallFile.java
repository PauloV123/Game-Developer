package com.flexstudios.world;
import java.awt.image.BufferedImage;

public class WallFile extends Tile{
	
	public WallFile(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
	}
	 
	public static void main(String[] args) {
	
	}

}
