package com.flexstudios.world;

import java.awt.image.BufferedImage;

public class Target extends Tile{

	public Target(int x, int y, BufferedImage sprite) {
		super(x, y, sprite);
		// TODO Auto-generated constructor stub
	}

}
