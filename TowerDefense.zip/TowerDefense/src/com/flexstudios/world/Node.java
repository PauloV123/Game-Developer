package com.flexstudios.world;

public class Node {
	
	public Vector2i tile;
	public Node parent;
	public double fCost, gCost,hCost;
	
	public Node(Vector2i tile, Node parent, double gCoste, double hCost) {
		this.tile = tile;
		this.parent = parent;
		this.gCost = gCost;
		this.hCost = hCost;
		this.fCost = gCost + hCost;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
