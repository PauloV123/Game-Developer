package com.flexstudios.graficos;


import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;



//import com.flexstudios.entities.Player;


public class UI {
	public static BufferedImage HEART = Game.spritesheet.getSprite(0, 16, 16, 16);
	public static BufferedImage MONEY = Game.spritesheet.getSprite(16, 16, 16, 16);
	public void render(Graphics g) {
		for(int i = 0; i < (int)(Game.lifeP); i++) {
			g.drawImage(HEART,10+(i*35),10,40,40,null);
		}
		g.setFont(new Font("arial", Font.BOLD,20));
		g.setColor(Color.white);
		g.drawString(""+Game.money, 42*15,39);
		g.drawImage(MONEY,37*16,5,40,40,null);
		
	}
	

}
