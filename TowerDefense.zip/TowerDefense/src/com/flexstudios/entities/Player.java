package com.flexstudios.entities;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;



public class Player extends Entity {
	
	public int xTarget, yTarget;
	public boolean attack;
	public Player(int x, int y, int width, int height,double speed ,BufferedImage sprite) {
		super(x, y, width, height,speed, sprite);
	
	}
	
	public void tick() {
		Enemy enemy = null;
		for(int i = 0; i < Game.entities.size();i++) {
			Entity e = Game.entities.get(i);
			if(e instanceof Enemy) {
				int xEnemy = e.getX();
				int yEnemy = e.getY();
				if(Entity.calculateDistance(this.getX(), this.getY(), xEnemy, yEnemy) < 50) {
					enemy =(Enemy) e;
				}
			}
		}
		if(enemy != null) {
			attack = true;
			xTarget = enemy.getX();
			yTarget = enemy.getY();
			enemy.life1-=0.2;
		}else {
			attack = false;
		}
	}
	
	public void render(Graphics g) {
		super.render(g);
		if(attack) {
			g.setColor(Color.red);
			g.drawLine((int)x + 7, (int)y+7, xTarget+10, yTarget+3);
		}
	}
	
	


}
