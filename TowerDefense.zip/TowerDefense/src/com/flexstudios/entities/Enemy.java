package com.flexstudios.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.AStar;
import com.flexstudios.world.Camera;
import com.flexstudios.world.Vector2i;
import com.flexstudios.world.World;

public class Enemy extends Entity{
	
	public double life1 = 12;

	
	
	private int frames = 0, maxFrames = 20, index = 0, maxIndex = 2;
	public static BufferedImage[] ENEMY;
	public Enemy(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		ENEMY = new BufferedImage[3];
		path = AStar.findPath(Game.world, new Vector2i(World.xInicial, World.yInicial), new Vector2i(World.xFINAL,World.yFINAL));
		for(int i = 0; i < 3; i++) {
			ENEMY[i] = Game.spritesheet.getSprite(32, 0+(i*16), 16, 16);
		}
	}
	
	public void tick() {
	
		frames++;
		
			if(frames == maxFrames) {
				frames = 0;
				index++;
				if(index > maxIndex) {
					index = 0;
				}
			}
		if(life1 <= 0) {
			Game.entities.remove(this);
			Game.money+=15;
			return;
		}
		
		followPath(path);
		if(x >= Game.WIDTH) {
			//perdemos vida
			
			Game.lifeP-=0.5;
			Game.entities.remove(this);
			
			return;
		}
		
	}
	public void render(Graphics g) {
		g.drawImage(ENEMY[index], this.getX() - Camera.x, this.getY()- Camera.y,null);
		g.setColor(Color.red);
		g.fillRect((int)x+1, (int)(y-3), 12,1);
		g.setColor(Color.green);
		g.fillRect((int)x+1, (int)(y-3), (int)((life1/12)*12),1);
	}
	
	
}
