package com.flexstudios.entities;

import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.World;

public class TowerController extends Entity{
	public boolean isPressed = false;
	public int xTarget, yTarget;
	public TowerController(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		
	}
	public void tick() {
		if(isPressed) {
			isPressed = false;
			boolean liberado = true;
			//cria torre no mapa
			int xx = (xTarget/16)*16;
			int yy = (yTarget/16)*16;
			Player player = new Player(xx,yy,16,16,0,Game.spritesheet.getSprite(0, 32, 16, 16));
			for(int i= 0 ; i < Game.entities.size(); i++) {
				Entity e = Game.entities.get(i);
				if(e instanceof Player) {
					if(Entity.isColidding(e, player)) {
						System.out.println("AQUI JA TEM UMA TORRE");
						liberado = false;
					}
				}
			}
		
			if(World.isFree(xx,yy)) {
				liberado = false;
			}
			if(liberado) {
				if(Game.money > 0) {
					Game.entities.add(player);
					Game.money-=20;
				}else if(Game.money <= 0) {
					Game.money = 0;
				}
			}
			
		}
		if(Game.lifeP == 0) {
			Game.gameState = "GAME_OVER";
		}
	}
}
