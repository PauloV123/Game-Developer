package com.flexstudios.entities;

import java.awt.image.BufferedImage;

import com.flexstudios.main.Game;
import com.flexstudios.world.Camera;

import java.awt.Color;
import java.awt.Graphics;
public class Spanner extends Entity{
	private int timer = 60;
	private int curTime = 0;
	
	
	public Spanner(double x, double y, int width, int height, double speed, BufferedImage sprite) {
		super(x, y, width, height, speed, sprite);
		// TODO Auto-generated constructor stub
		
	}
	public void tick() {
		//criar inimigos
		curTime++;
		if(curTime == timer) {
			//Cria o inimigo
			curTime = 0;
			timer = Entity.rand.nextInt(60 - 30) + 30;
			Enemy enemy = new Enemy(x,y,16,16,0.7,Entity.ENEMY1_SPRITE);
			Game.entities.add(enemy);
		}
		
		
		
	}
	public void render(Graphics g) {
		
	}

}
